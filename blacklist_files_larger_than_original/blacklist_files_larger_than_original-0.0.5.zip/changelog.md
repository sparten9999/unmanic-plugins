
**<span style="color:#56adda">0.0.1</span>**
- initial release

**<span style="color:#56adda">0.0.2</span>**
- changed file size from bytes to human readable text

**<span style="color:#56adda">0.0.5</span>**
- added changelog and description
- changed headers in csv
